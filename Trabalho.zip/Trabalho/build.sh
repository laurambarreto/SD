cd src/main/googol
javac -d ../../../target/ -cp ../../../target/lib/jsoup-1.18.3.jar *.java
cd ../../../