cd target/
java -cp "./lib/jsoup-1.18.3.jar:." googol.Gateway 8000
cd ..