cd target/
java -cp "./lib/jsoup-1.18.3.jar:." googol.Downloader 127.0.0.1 8000
cd ..